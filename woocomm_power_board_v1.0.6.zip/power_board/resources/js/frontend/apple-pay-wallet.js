import walletsForm from "../includes/wallets-form";

walletsForm(
    'apple-pay',
    'Power Board Apple Pay',
    'powerBoardWalletApplePayButton',
    [
        'first_name',
        'last_name',
        'email',
        'address_1',
        'city',
        'state',
        'country',
        'postcode',
    ]
);
