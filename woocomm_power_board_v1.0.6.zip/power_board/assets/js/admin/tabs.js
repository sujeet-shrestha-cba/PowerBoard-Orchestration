jQuery('.pay-dock-active-hidden-settings').hide();
